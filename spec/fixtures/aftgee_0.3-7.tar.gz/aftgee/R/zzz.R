.First.lib <- function(lib, pkg) {
	library.dynam("aftgee", pkg, lib)
}
